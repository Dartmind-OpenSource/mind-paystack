class AppApiEndpoints {
  static String verifyTransaction = '/transaction/verify';
  static String getTransactionStatus = '/transaction/status';
  static String initializePayment = '/initialize/payment';
  static String verifyPayment = '/payment/verify';
  static String getPaymentStatus = '/payment/status';
  static String getBanks = '/get/Banks';
  static String resol = '/get/Banks';
}
